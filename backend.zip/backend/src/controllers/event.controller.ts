import type { Request, Response } from "express";
import Event from "../models/event.model.ts";

export const createEvent = async (req: Request, res: Response) => {
  try {
    const {
      title,
      description,
      date,
      time,
      location,
      createdBy,
      estimatedBudget,
      capacity,
      isPublic,
      rsvpDeadline,
      category,
    } = req.body;

    const newEvent = new Event({
      title,
      description,
      date,
      time,
      location,
      createdBy,
      estimatedBudget,
      capacity,
      isPublic,
      rsvpDeadline,
      category,
    });

    await newEvent.save();

    res
      .status(201)
      .json({ success: true, message: "Event created successfully" });
  } catch (error) {
    console.log("Error in createEvent controller: ", error);
    res.status(500).json({
      success: false,
      message: "Internal server error",
    });
  }
};
