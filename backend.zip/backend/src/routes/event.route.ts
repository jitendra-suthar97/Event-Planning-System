import { Router } from "express";
import { isAuthenticated } from "../middlewares/auth.ts";
import { createEvent } from "../controllers/event.controller.ts";

const router = Router();

router.post("/create-event", isAuthenticated, createEvent);

export default router;
